import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messagehome',
  templateUrl: './messagehome.page.html',
  styleUrls: ['./messagehome.page.scss'],
})
export class MessagehomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
