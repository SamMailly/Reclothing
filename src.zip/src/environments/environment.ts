// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyCDKC0ghW8oo_XdT0OBArQmbILlAt-rr6I",
    authDomain: "reclothing-43e3c.firebaseapp.com",
    databaseURL: "https://reclothing-43e3c.firebaseio.com",
    projectId: "reclothing-43e3c",
    storageBucket: "reclothing-43e3c.appspot.com",
    messagingSenderId: "819422822851",
    appId: "1:819422822851:web:92b916da4cd21335d5bd76",
    measurementId: "G-ZXKCQ39M8D"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
